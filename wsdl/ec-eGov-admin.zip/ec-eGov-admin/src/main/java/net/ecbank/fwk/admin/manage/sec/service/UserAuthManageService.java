package net.ecbank.fwk.admin.manage.sec.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import net.ecbank.fwk.admin.manage.sec.dto.UserAuthDto;
import net.ecbank.fwk.admin.manage.user.repository.EcUserRepository;
import net.ecbank.fwk.admin.manage.user.repository.EmployeeRepository;
import net.ecbank.fwk.admin.manage.user.repository.VendorUserRepository;

@Service
public class UserAuthManageService {
	
	@Autowired
	private EmployeeRepository empRep;
	
	@Autowired
	private VendorUserRepository venUsrRep;
	
	@Autowired
	private EcUserRepository ecUserRep;
	
	public Page<UserAuthDto> searchUserList(UserAuthDto userAuthDto){
		
		Page<UserAuthDto> list = null;
		
		PageRequest pr = PageRequest.of(userAuthDto.getPage()-1,userAuthDto.getRows(),Sort.by(Direction.DESC,"userCls"));
		
		if(userAuthDto.getUserGbn().equals("EMP")) {
			//list = empRep.findByEmpNoContainingAndEmpNmContaining(userAuthDto.getUserId(), userAuthDto.getUserNm());
			list = ecUserRep.findByUserIdContainingAndUserNmContainingAndUserCls(userAuthDto.getUserId(), userAuthDto.getUserNm(), "B", pr);
		}else {
			list = ecUserRep.findByUserIdContainingAndUserNmContainingAndUserCls(userAuthDto.getUserId(), userAuthDto.getUserNm(), "S", pr);
			//list = venUsrRep.findByUserIdContainingAndUserNmContaining(userAuthDto.getUserId(), userAuthDto.getUserNm());
		}
		
		return list;
	}
	
}
