package net.ecbank.fwk.admin.manage.sys.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.ecbank.fwk.admin.manage.sys.entity.MenuAuthRel;

public interface MenuAuthRelRepository extends JpaRepository<MenuAuthRel, String> {

}
