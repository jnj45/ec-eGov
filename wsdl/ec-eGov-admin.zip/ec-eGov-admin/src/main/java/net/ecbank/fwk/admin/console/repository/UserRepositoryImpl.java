package net.ecbank.fwk.admin.console.repository;

public class UserRepositoryImpl {

}
