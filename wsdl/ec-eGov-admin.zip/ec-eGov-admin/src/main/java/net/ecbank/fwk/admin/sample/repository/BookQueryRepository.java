package net.ecbank.fwk.admin.sample.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookQueryRepository {

}
