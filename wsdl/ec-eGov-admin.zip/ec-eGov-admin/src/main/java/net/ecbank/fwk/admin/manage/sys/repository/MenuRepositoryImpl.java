package net.ecbank.fwk.admin.manage.sys.repository;

import com.querydsl.jpa.impl.JPAQueryFactory;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class MenuRepositoryImpl {
	
	private final JPAQueryFactory queryFactory;
	
	
}
