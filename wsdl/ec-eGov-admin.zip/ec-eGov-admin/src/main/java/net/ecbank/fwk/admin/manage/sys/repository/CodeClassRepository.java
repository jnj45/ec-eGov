package net.ecbank.fwk.admin.manage.sys.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.ecbank.fwk.admin.manage.sys.entity.CodeClass;

public interface CodeClassRepository extends JpaRepository<CodeClass, String> {

}
